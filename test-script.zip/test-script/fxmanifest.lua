fx_version 'cerulean'
game 'gta5'
author 'Jeromebro'
version '1.0.0'
description 'Show resource for UI Obfuscator'

ui_page 'html/index.html'

files {
    'html/*.*',
    'html/js-load/*.js'
}

-- node_modules, js folder, build.js, package.json, yarn files
-- ARE NOT LOADED because them are only needed for the developement // fivem dont need them
-- NEVER load anything anywhere from the normal js folder, this is only for writing the ui
-- in fivem only load the js-load folder (obfuscated)