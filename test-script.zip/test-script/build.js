const fs = require('fs-extra');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');
const chokidar = require('chokidar');
const crypto = require('crypto');
const os = require('os');

const colors = {
    reset: '\x1b[0m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m'
};

class FiveMBuilder {
    constructor() {
        this.config = {
            sourceDir: './html/js',
            outputDir: './html/js-load',
            cacheDir: './.build-cache',
            isDev: process.argv.includes('--dev'),
            isProd: process.argv.includes('--prod'),
            isWatch: process.argv.includes('--watch'),
            useCache: !process.argv.includes('--no-cache'),
            parallel: !process.argv.includes('--no-parallel')
        };

        this.obfuscatorOptions = {
            compact: true,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 0.6,
            deadCodeInjection: true,
            deadCodeInjectionThreshold: 0.3,
            debugProtection: true,
            debugProtectionInterval: 1500,
            disableConsoleOutput: true,
            identifierNamesGenerator: 'hexadecimal',
            log: false,
            numbersToExpressions: true,
            renameGlobals: false,
            selfDefending: true,
            simplify: true,
            splitStrings: true,
            splitStringsChunkLength: 8,
            stringArray: true,
            stringArrayCallsTransform: true,
            stringArrayEncoding: ['base64'],
            stringArrayIndexShift: true,
            stringArrayRotate: true,
            stringArrayShuffle: true,
            stringArrayWrappersCount: 1,
            stringArrayWrappersChainedCalls: true,
            stringArrayWrappersParametersMaxCount: 3,
            stringArrayWrappersType: 'function',
            stringArrayThreshold: 0.6,
            transformObjectKeys: true,
            unicodeEscapeSequence: false,
            seed: 12345,
            target: 'browser'
        };

        this.devObfuscatorOptions = {
            compact: false,
            controlFlowFlattening: false,
            deadCodeInjection: false,
            debugProtection: false,
            disableConsoleOutput: false,
            log: false,
            renameGlobals: false,
            selfDefending: false,
            stringArray: false,
            transformObjectKeys: false
        };

        this.cache = new Map();
        this.startTime = Date.now();
        this.workers = [];
    }

    log(message, color = 'white') {
        const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(2);
        console.log(colors[color] + `[${elapsed}s] ${message}` + colors.reset);
    }

    // Schneller File Hash für Cache
    getFileHash(content) {
        return crypto.createHash('md5').update(content).digest('hex').substring(0, 12);
    }

    async loadCache() {
        if (!this.config.useCache) return;

        try {
            await fs.ensureDir(this.config.cacheDir);
            const cacheFile = path.join(this.config.cacheDir, 'obfuscation-cache.json');

            if (await fs.pathExists(cacheFile)) {
                const cacheData = await fs.readJSON(cacheFile);
                for (const [key, value] of Object.entries(cacheData)) {
                    this.cache.set(key, value);
                }
                this.log(`Cache geladen: ${this.cache.size} Einträge`, 'cyan');
            }
        } catch (error) {
            this.log('Cache-Fehler: ' + error.message, 'yellow');
        }
    }

    async saveCache() {
        if (!this.config.useCache || this.cache.size === 0) return;

        try {
            const cacheFile = path.join(this.config.cacheDir, 'obfuscation-cache.json');
            const cacheObj = Object.fromEntries(this.cache);
            await fs.writeJSON(cacheFile, cacheObj);
            this.log(`Cache gespeichert: ${this.cache.size} Einträge`, 'cyan');
        } catch (error) {
            this.log('Cache-Speicher-Fehler: ' + error.message, 'yellow');
        }
    }

    async init() {
        this.startTime = Date.now();
        this.log('FiveM Resource Builder gestartet...', 'cyan');

        await this.loadCache();
        await this.createDirectories();

        if (this.config.isWatch) {
            await this.watchFiles();
        } else {
            await this.buildAll();
        }
    }

    async createDirectories() {
        try {
            await Promise.all([
                fs.ensureDir(this.config.sourceDir),
                fs.ensureDir(this.config.outputDir),
                fs.ensureDir(this.config.cacheDir)
            ]);

            this.log('Ordner bereit', 'blue');
        } catch (error) {
            this.log('Ordner-Fehler: ' + error.message, 'red');
        }
    }

    async buildAll() {
        this.log('Starte Build...', 'yellow');
        try {
            const files = await this.getJSFiles(this.config.sourceDir);
            if (files.length === 0) {
                this.log('Keine JS-Dateien gefunden', 'yellow');
                return;
            }
            this.log(`${files.length} Dateien gefunden`, 'blue');
            if (this.config.parallel && files.length > 1) {
                await this.processFilesParallel(files);
            } else {
                for (const file of files) {
                    await this.processFile(file);
                }
            }
            await this.saveCache();
            const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(2);
            this.log(`Build abgeschlossen in ${elapsed}s!`, 'green');
        } catch (error) {
            this.log('Build-Fehler: ' + error.message, 'red');
        }
    }

    async processFilesParallel(files) {
        const batchSize = Math.min(files.length, os.cpus().length);
        const batches = [];

        for (let i = 0; i < files.length; i += batchSize) {
            batches.push(files.slice(i, i + batchSize));
        }

        this.log(`Parallele Verarbeitung: ${batches.length} Batches`, 'cyan');

        for (const batch of batches) {
            const promises = batch.map(file => this.processFile(file));
            await Promise.all(promises);
        }
    }

    async getJSFiles(dir) {
        const files = [];

        try {
            const items = await fs.readdir(dir, { withFileTypes: true });

            const promises = items.map(async (item) => {
                const fullPath = path.join(dir, item.name);

                if (item.isDirectory()) {
                    return await this.getJSFiles(fullPath);
                } else if (item.name.endsWith('.js')) {
                    return [fullPath];
                }
                return [];
            });

            const results = await Promise.all(promises);
            files.push(...results.flat());
        } catch (error) {
            if (error.code !== 'ENOENT') {
                throw error;
            }
        }

        return files;
    }

    async processFile(filePath) {
        try {
            const relativePath = path.relative(this.config.sourceDir, filePath);
            const outputPath = path.join(this.config.outputDir, relativePath);
            const sourceCode = await fs.readFile(filePath, 'utf8');
            if (this.config.useCache) {
                const fileHash = this.getFileHash(sourceCode);
                const cacheKey = `${relativePath}:${fileHash}:${this.config.isDev ? 'dev' : 'prod'}`;

                if (this.cache.has(cacheKey)) {
                    const cachedCode = this.cache.get(cacheKey);
                    await fs.ensureDir(path.dirname(outputPath));
                    await fs.writeFile(outputPath, cachedCode);
                    this.log(`CACHE: ${relativePath}`, 'cyan');
                    return;
                }
            }

            await fs.ensureDir(path.dirname(outputPath));

            let processedCode;

            if (this.config.isDev) {
                const result = JavaScriptObfuscator.obfuscate(sourceCode, this.devObfuscatorOptions);
                processedCode = result.getObfuscatedCode();
                this.log(`DEV: ${relativePath}`, 'blue');
            } else {
                const result = JavaScriptObfuscator.obfuscate(sourceCode, this.obfuscatorOptions);
                processedCode = result.getObfuscatedCode();
                this.log(`PROD: ${relativePath}`, 'magenta');
            }

            await fs.writeFile(outputPath, processedCode);

            if (this.config.useCache) {
                const fileHash = this.getFileHash(sourceCode);
                const cacheKey = `${relativePath}:${fileHash}:${this.config.isDev ? 'dev' : 'prod'}`;
                this.cache.set(cacheKey, processedCode);
            }

        } catch (error) {
            this.log(`Fehler bei ${filePath}: ${error.message}`, 'red');
        }
    }

    async watchFiles() {
        this.log('Watch Mode aktiviert...', 'cyan');
        this.log('Überwache: ' + this.config.sourceDir, 'blue');

        const watcher = chokidar.watch(path.join(this.config.sourceDir, '**/*.js'), {
            persistent: true,
            ignoreInitial: false,
            ignorePermissionErrors: true,
            atomic: true,
            awaitWriteFinish: {
                stabilityThreshold: 100,
                pollInterval: 50
            }
        });

        watcher.on('add', (filePath) => {
            this.log(`Datei hinzugefügt: ${path.relative(process.cwd(), filePath)}`, 'green');
            this.processFile(filePath).catch(console.error);
        });

        watcher.on('change', (filePath) => {
            this.log(`Datei geändert: ${path.relative(process.cwd(), filePath)}`, 'yellow');
            this.processFile(filePath).catch(console.error);
        });

        watcher.on('unlink', (filePath) => {
            const relativePath = path.relative(this.config.sourceDir, filePath);
            const outputPath = path.join(this.config.outputDir, relativePath);

            fs.remove(outputPath).then(() => {
                this.log(`Datei entfernt: ${relativePath}`, 'red');
            }).catch(console.error);
        });

        this.log('Watch Mode läuft. Drücke Ctrl+C zum Beenden...', 'green');
    }
}

if (require.main === module) {
    const builder = new FiveMBuilder();

    if (process.argv.includes('--help') || process.argv.includes('-h')) {
        console.log(`
Usage:
  npm run build          - Build alle Dateien (Production)
  npm run build:dev      - Build alle Dateien (Development)  
  npm run build:prod     - Build alle Dateien (Production)
  npm run watch          - Watch Mode

Performance Flags:
  --no-cache            - Cache deaktivieren
  --no-parallel         - Parallele Verarbeitung deaktivieren
        `);
        process.exit(0);
    }

    builder.init().catch(console.error);
}

module.exports = FiveMBuilder;